//package View;
//
//import java.awt.Color;
//
//public class Themes {
//
//	
//	public void setTheme(String theme){
//		if ( theme == "Default theme"){
//			this.p1color = Color.RED;
//			this.p2color = Color.BLACK;
//			this.squareColor = Color.GRAY;
//					
//		} else if ( theme == "Pink theme"){
//			this.p1color = Color.MAGENTA;
//			this.p2color = Color.GREEN;
//			this.squareColor = Color.PINK;
//		}
//	}
//	
//	
//}
