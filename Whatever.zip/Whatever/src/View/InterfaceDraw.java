package View;

import java.awt.Graphics;
import java.awt.Point;
import java.util.List;
import Model.Pieces;

interface InterfaceDraw {

	void drawPieces(Graphics g, Point point, int pieceSize, Pieces piece);
	
	void drawListOfPieces(Graphics g, List<Pieces> pieceList, int pieceSize);
	
}