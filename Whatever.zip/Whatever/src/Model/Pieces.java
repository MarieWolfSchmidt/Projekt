package Model;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;



public class Pieces  {

	private Color color;
	private Point point;
	
	public Pieces(Color color, Point point) {
		this.color = color;
		this.point = point;
	}

	public static boolean contains(int x, int y, Point point, int squareSize) {
	      return (point.x - x) * (point.x - x) + (point.y - y) * (point.y - y) < squareSize / 2 * 
	    		  squareSize / 2;
	   }
	
	public Color getColor() {
		return this.color;
	}
	
	public void setPoint(Point point) {
		this.point = point;
	}
	
	public Point getPoint() {
		return this.point;
	}

}
