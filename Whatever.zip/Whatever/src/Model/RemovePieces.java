package Model;

import java.util.List;

public class RemovePieces {

	public RemovePieces() {
		
	}
	
	public List<Pieces> removeAllPiecesInList(List<Pieces> pieceList) {
		
		// Removes all pieces from the pieceList when the user presses the back to menu button in the game() menu.
		List<Pieces> returnList = pieceList;
		returnList.clear();
		return returnList;
	}
	
}
