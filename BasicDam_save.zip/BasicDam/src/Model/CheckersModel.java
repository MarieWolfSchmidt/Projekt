package Model;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import View.CheckersView;

public class CheckersModel{

	private CheckersView view;
	private List<Pieces> pieceList;
	public MovePieces move;
	
	private int boardSize = 600;
	private int squareDim;
	protected int finalBoardSize; // If the supplied commandLineArgument is an odd number then we change the boardSize so it matches.
	private int pieceSize;
	private boolean isKing; 

	
	private int oldCmdLineArgument;
	private int oldSquareDim;
	private int oldFinalBoardSize;
	private int oldPieceSize;
	
	
	
	
	public CheckersModel(CheckersView view) {
		this.view = view;
    	this.squareDim = boardSize/view.cmdLineArgument; 
    	this.finalBoardSize = squareDim*view.cmdLineArgument;
    	this.pieceSize = (squareDim/3)*2;
    	this.pieceList = new ArrayList<>();
    	this.move = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize);
    	this.oldCmdLineArgument=view.cmdLineArgument; // used in load. 
    	
	}
	
	public void game() {
    	
		add(1, 1, 1, squareDim, pieceList);
    	add(2, view.cmdLineArgument, view.cmdLineArgument, squareDim, pieceList);
		this.view.menu.game(view.cmdLineArgument, pieceList, boardSize, squareDim, finalBoardSize, pieceSize);
		
	}
		
	public void menu() {
		this.view.menu.menu();
	}
	
	public void mousePressed(MouseEvent e) {		
		move.pressed(e);
		saveBoard();
	}
	
	public void mouseDragged(MouseEvent e) {
		move.mouseDragged(e, view.menu.draw);
	}
	
	public void mouseReleased(MouseEvent e) {
		move.released(e, view.menu.draw, view.menu);
		
		
	}
	
	public void add(int i, int row, int col, int squareDim, List<Pieces> pieceList) {
		// Instantiates a piece and adds it to the pieceList. 
		
		Point p = new Point((col-1)*squareDim+squareDim/2,(row-1)*squareDim+squareDim/2); 
		Pieces piece = new Pieces(i,p,isKing);
	    pieceList.add(piece);     
	}
	
	public void save(){
		// When the button "Save Game" is pressed, the progam will save the pieceList and the move to the file SavedGame.sav.
		// pieceList is used to save the individual buttons (we need color and isKing), and move is used to save the positions.
		
		
		try{
			FileOutputStream saveGame = new FileOutputStream("SavedGame.game");
			ObjectOutputStream save = new ObjectOutputStream(saveGame);
			save.writeObject(pieceList);
			save.writeObject(move);
			save.writeObject(oldCmdLineArgument);
			save.close();
			System.out.println("Game is saved");
			
		}	catch (Exception exc){ // In case something is wrong, the function will stop. 
			exc.printStackTrace();
		}
	}
	
	public void load(){
		// When the button "Continue Game" is pressed, the program will load SaveGame.sav and return the values to the variables. 
		// Then the game starts up with the saved values. When the game has to reload the old board, it has to save the old cmdLineArg.
		// Afterwards it uses this value to calculate the old values. 
		
		try{
			FileInputStream loadGame = new FileInputStream("SavedGame.game");
			ObjectInputStream load = new ObjectInputStream(loadGame);
			
			pieceList = (ArrayList<Pieces>) load.readObject();
			move = (MovePieces) load.readObject();
			oldCmdLineArgument = (int) load.readObject();
			
			oldSquareDim = boardSize/oldCmdLineArgument; 
			oldFinalBoardSize = squareDim*oldCmdLineArgument;
			oldPieceSize = (oldSquareDim/3)*2;
			
			this.view.menu.game(oldCmdLineArgument, pieceList,boardSize, oldSquareDim, oldFinalBoardSize, oldPieceSize);
			
		} catch (Exception exc){
			exc.printStackTrace();
			System.out.println("File was not found");
		}
	}
	
	public void saveBoard(){
		// The positions of the pieces is saved each time the mouse is pressed. 
		try{
			FileOutputStream saveBoard = new FileOutputStream("SavedBoard.game");
			ObjectOutputStream save = new ObjectOutputStream(saveBoard);
			save.writeObject(pieceList);
			save.writeObject(move);
			save.close();
			System.out.println("board Saved");
			
		
			
		}	catch (Exception exc){ // In case something is wrong, the function will stop. 
			exc.printStackTrace();
			System.out.println("File was not found");
		}
	}
	
	
	public void undo(){
		// Loads SaveBoard.sav. 
		
		try{
			FileInputStream loadBoard = new FileInputStream("SavedBoard.game");
			ObjectInputStream load = new ObjectInputStream(loadBoard);
			pieceList = (ArrayList<Pieces>) load.readObject();
			move = (MovePieces) load.readObject();
				
			this.view.menu.game(view.cmdLineArgument, pieceList, boardSize, squareDim, finalBoardSize, pieceSize);
			
			
		} catch (Exception exc){
			exc.printStackTrace();
		}
	}
	
	
	
	public void removePieces() {
		
		// Removes all pieces from the pieceList when the user presses the back to menu button in the game() menu.
			
			this.pieceList.clear();
	}
	
}





