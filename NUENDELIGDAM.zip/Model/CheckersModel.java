package Model;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import View.CheckersView;

public class CheckersModel {

	// The CheckersModel class supports manipulating the data. When an actionevent occurs the corresponding event
	// calls a method from this class and the view gets updated.  
	
	// Instantiating variables. 
	
	private CheckersView view;
	private MovePieces movePieces;
	
	private List<Pieces> pieceList;
	
	private int squareDim;
	private int pieceSize;
	private int boardSize = 600;
	protected int finalBoardSize; // If the supplied commandLineArgument is an odd number then we change the boardSize so it matches.
	
	
	public CheckersModel(CheckersView view) {
		this.view = view;
    	this.squareDim = boardSize/view.cmdLineArgument; 
    	this.finalBoardSize = squareDim*view.cmdLineArgument;
    	this.pieceSize = (squareDim/3)*2;
    	this.pieceList = new ArrayList<>();
    	this.movePieces = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize);
	}
	
	public void game() {
		// Game is called from the CheckersController when the button "New Game" is pressed. 
		// The two pieces gets added and the game can begin.
    	add(1, 1, 1, squareDim, pieceList);
    	add(2, view.cmdLineArgument, view.cmdLineArgument, squareDim, pieceList);
		this.view.menu.game(view.cmdLineArgument, pieceList, boardSize, squareDim, finalBoardSize, pieceSize);
	}
	
	public void menu() {
		// Calls the menu GUI.
		this.view.menu.menu();
	}
	
	public void mousePressed(MouseEvent e) {
		// A mouse pressed event.
		movePieces.pressed(e);
	}
	
	public void mouseDragged(MouseEvent e) {
		// A mouse dragged event.
		movePieces.mouseDragged(e, view.menu.draw);
	}
	
	public void mouseReleased(MouseEvent e) {
		// A mouse released event.
		movePieces.released(e, view.menu.draw, view.menu);
	}
	
	public void add(int i, int row, int col, int squareDim, List<Pieces> pieceList) {
		
		// Instantiates a piece and adds it to the pieceList. 
		
		Point p = new Point((col-1)*squareDim+squareDim/2,(row-1)*squareDim+squareDim/2); 
		Pieces piece = new Pieces(i,p);
	    pieceList.add(piece);     
	}
	
	public void removePieces() {
		
		// Removes all pieces from the pieceList when the user presses the back to menu button in the game() menu.
		//And reset the turn. 
			this.pieceList.clear();
			this.movePieces.resetTurn();
	}
	
}
