package View;
import java.awt.Color;
import java.awt.Toolkit;

import javax.swing.JFrame;

import Model.CheckersModel;



public class CheckersView extends JFrame {
	
	// The CheckersView governs what's shown on the screen and what's not. 
	
	// Instantiating variables. 
	protected CheckersModel checker;
	public Menus menu;
	public int cmdLineArgument;
	
	public CheckersView(int cmdLineArgs){
		this.cmdLineArgument = cmdLineArgs;
		
		checker = new CheckersModel(this);
		menu = new Menus(this);
		
		// Sets the size of the frame. 
		this.setBounds(200, 60, 1000, 635);
		this.getContentPane().setBackground(Color.LIGHT_GRAY);
		this.getContentPane().setLayout(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);		
		this.setResizable(false);
		
		// Calls the menu.
		menu.menu();
	}
	
	public void showIt(String title){
		// Shows the JFrame. 
		 this.setTitle(title);
		 this.setVisible(true);
	}
	
}