package Model;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Music {
	// The Music class handles loading music and playing it when requested.
		
	// Instantiating variables.
	private Clip soundtrack;
	private boolean isMusicOn = false;

	public void toggleMusic() {
		if (isMusicOn == false ){
			activateMusic();
			this.isMusicOn = true;
		} else {
			stopMusic();
			this.isMusicOn = false;
		}		
	}
	
	public void activateMusic(){
		// Loads the music file and starts playing it.
		try {
			InputStream in = new FileInputStream("eye.wav");
			 InputStream bufferedIn = new BufferedInputStream(in);
			 soundtrack = AudioSystem.getClip();
			 AudioInputStream ais = AudioSystem.getAudioInputStream(bufferedIn);
			 
			 soundtrack.open(ais);
			 soundtrack.loop(Clip.LOOP_CONTINUOUSLY); // Makes sure that the song starts again after it is finished.
		 } catch (Exception ex) {
			 System.out.println("Sound file not found");
		 }
	}
	
	public void stopMusic() {
		soundtrack.stop();
		isMusicOn = false;
	}
	
	public void keepMusicPlaying() {
		// This method is only for certain circumstances when the user has activated the music in settings and starts a new game.
		if (isMusicOn == false) {
			activateMusic();
			isMusicOn = true;
		}
	}
	
	
}
