package Model;

import java.util.List;

public class RemovePieces {

	// Removes all pieces from the pieceList when the user presses the back to menu button in the game() menu.
	
	public RemovePieces() {
		
	}
	
	public List<Pieces> removeAllPiecesInList(List<Pieces> pieceList) {
		
		List<Pieces> returnList = pieceList;
		returnList.clear();
		return returnList;
	}
	
}
