package View;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.List;
import Model.Pieces;

interface InterfaceDraw {
	
	// This interface is only implemented by the two drawing classes, DrawOnScorePanel and DrawOnBoardPanel.

	void drawPieces(Graphics g, Point point, int pieceSize, Pieces piece, Color playerOne, Color playerTwo);
	
	void drawListOfPieces(Graphics g, List<Pieces> pieceList, int pieceSize, Color playerOne, Color playerTwo);
	
}