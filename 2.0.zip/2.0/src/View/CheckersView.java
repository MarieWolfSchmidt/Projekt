package View;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Model.CheckersModel;

public class CheckersView extends JFrame {
	
	// The CheckersView Class creates the frame that everything in the game is built on.
		
	// Instantiating variables.
	private static final long serialVersionUID = 1L;
	protected CheckersModel checker;
	public int cmdLineArgument;
	
	public GameMenu menu;
	public MenuBar titleBar;
	public MainMenu mainMenu;
	public SettingsMenu settingsMenu;
	public RulesMenu rulesMenu;
	public HowToMenu howToMenu;
	public CreditsMenu creditsMenu;
	
	public CheckersView(int cmdLineArgs) {
		
		this.cmdLineArgument = cmdLineArgs;
		
		// Creates all the menus needed for running the game. All the menus are called through view.
		// This is done to separate the code into more manageable packets using the MVC model.
		checker = new CheckersModel(this);
		menu = new GameMenu(this);
		titleBar = new MenuBar(this);
		mainMenu = new MainMenu(this);
		settingsMenu = new SettingsMenu(this);
		rulesMenu = new RulesMenu(this);
		howToMenu = new HowToMenu(this);
		creditsMenu = new CreditsMenu(this);
		
		// Setting up the JFrame
		this.setBounds(200, 60, 1280, 880);
		this.getContentPane().setBackground(Color.LIGHT_GRAY);
		this.getContentPane().setLayout(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	
		this.setResizable(false);
		
		// Loading and setting the background image.
		ImageIcon imgic = new ImageIcon("bakk.png");
		Image img = imgic.getImage();		
		this.setContentPane(new JLabel(new ImageIcon(img)));
		
		titleBar.menuBar(this);
		mainMenu.menu();
	}
	
	public void showIt(String title) {
		// Shows JFrame.
		this.setTitle(title);
		this.setVisible(true);
	}

}