package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;

import Model.Pieces;

public class DrawOnScorePanel extends JComponent implements InterfaceDraw {
	// The DrawOnScorePanel handles everything that has to do with drawing on the score panel.
	
	// Instantiating variables.

	private static final long serialVersionUID = 1L;

	private int slainPiecesPlayerOne, slainPiecesPlayerTwo;
	private int SLAINPIECESTODRAW = 15;
	private int YVALUEADDED = 12;
	private int INITIALYVALUERED = 750;
	private int INITIALYVALUEBLACK = 50;
	private int PIECESIZE = 66;
	
	private Color colorPlayerOne, colorPlayerTwo;
	
	private boolean isKing = false;
	
	public DrawOnScorePanel(Color playerOne, Color playerTwo) {
		
		// Draws on the score panel
		this.colorPlayerOne = playerOne;
		this.colorPlayerTwo = playerTwo;
	}
	
	protected void paintComponent(Graphics g) {
		
		// Override jComponent's function paintComponent to draw the board and the pieces.
		drawSlainPieces(g, this.slainPiecesPlayerOne, this.slainPiecesPlayerTwo);
	 }
	
	public void drawSlainPieces(Graphics g, int slainPiecesPlayerOne, int slainPiecesPlayerTwo) {
		
		// Draws the slain pieces on the score panel just right of the board. 
		int amountOfDrawnPiecesPlayerOne;
		int amountOfDrawnPiecesPlayerTwo;
		
		// If the number of slain pieces overtakes the set amount of pieces to be drawn then the rest amount of pieces
		// i.e. anything > 12 will be written as a string to the right of the pieces drawn. 
		if (slainPiecesPlayerOne > SLAINPIECESTODRAW) {
			amountOfDrawnPiecesPlayerOne = SLAINPIECESTODRAW;
		} else {
			amountOfDrawnPiecesPlayerOne = slainPiecesPlayerOne;
		}
		if (slainPiecesPlayerTwo > SLAINPIECESTODRAW) {
			amountOfDrawnPiecesPlayerTwo = SLAINPIECESTODRAW;
		} else {
			amountOfDrawnPiecesPlayerTwo = slainPiecesPlayerTwo;
		}
		if (slainPiecesPlayerOne > SLAINPIECESTODRAW || slainPiecesPlayerTwo > SLAINPIECESTODRAW) {
			drawPlusPiecesString(g, slainPiecesPlayerOne, slainPiecesPlayerTwo);
		}
		
		// Draws the red pieces on the opposit side of red.
		List<Pieces> slainList = new ArrayList<Pieces>();
		if (slainPiecesPlayerOne > 0) {
			int initialYvalueOfPoint = INITIALYVALUERED;
			for (int i = 0; i < amountOfDrawnPiecesPlayerOne; i++) {
				Point initialPoint = new Point(50,initialYvalueOfPoint);
				Pieces piece = new Pieces(colorPlayerOne,initialPoint, isKing);
				slainList.add(piece);
				initialYvalueOfPoint -= YVALUEADDED;
			}	
		}
		drawListOfPieces(g, slainList, this.PIECESIZE, colorPlayerOne, colorPlayerTwo);
		slainList.clear(); // Clears the list to fill it again and draw the other side. 
		
		// Draws the black pieces on the opposit side of red.
		if (slainPiecesPlayerTwo > 0) {
			int initialYvalueOfPoint = INITIALYVALUEBLACK;
			for (int i = 0; i < amountOfDrawnPiecesPlayerTwo; i++) {
				Point initialPoint = new Point(50,initialYvalueOfPoint);
				Pieces piece = new Pieces(colorPlayerTwo,initialPoint, isKing);
				slainList.add(piece);
				initialYvalueOfPoint += YVALUEADDED;
			}	
		}
		drawListOfPieces(g, slainList, this.PIECESIZE, colorPlayerOne, colorPlayerTwo);
	}
	
	public void drawPlusPiecesString (Graphics g, int slainPiecesPlayerOne, int slainPiecesPlayerTwo) {
	
		// Draws the given string if the amount of pieces > 12, because with 100 x 100 there will be space problems in the GUI.
		if (slainPiecesPlayerOne > SLAINPIECESTODRAW) {
			int slainPiecesOverTwelve;
		    slainPiecesOverTwelve = slainPiecesPlayerOne - SLAINPIECESTODRAW;
		    Font font = new Font("Verdana", Font.BOLD, 20);
		    g.setFont(font);
			g.drawString("+" + slainPiecesOverTwelve, 35, 300);
		} 
		
		if (slainPiecesPlayerTwo > SLAINPIECESTODRAW) {
			int slainPiecesOverTwelve;
			slainPiecesOverTwelve = slainPiecesPlayerTwo - SLAINPIECESTODRAW;
			Font font = new Font("Verdana", Font.BOLD, 20);
		    g.setFont(font);
			g.drawString("+" + slainPiecesOverTwelve, 35, 510);
		}
	}
	
	public void drawPieces(Graphics g, Point point, int pieceSize, Pieces piece, Color playerOne, Color playerTwo) {
		
		// Draws the individual pieces that has been slain.
		int x = (point.x - pieceSize / 2);
		int y = (point.y - pieceSize / 2);
		if (piece.getColor().equals(playerOne)) {
			g.setColor(playerOne);
			g.fillOval(x, y, PIECESIZE, PIECESIZE);
			g.setColor(Color.WHITE);
			g.drawOval(x, y, 66, 66);
		} else if (piece.getColor().equals(playerTwo)) {
			g.setColor(playerTwo);
		    g.fillOval(x, y, PIECESIZE, PIECESIZE);
		    g.setColor(Color.WHITE);
			g.drawOval(x, y, PIECESIZE, PIECESIZE);
		}
	}
	
	public void drawListOfPieces(Graphics g, List<Pieces> pieceList, int pieceSize, Color playerOne, Color playerTwo) {
		
		// Draws all the pieces in the given list.
		for(Pieces piece: pieceList) {
	    	drawPieces(g, piece.getPoint(), pieceSize, piece, playerOne, playerTwo);
	    }
	}
	
	public void repaintScorePanel(int slainPiecesPLayerOne, int slainPiecesPlayerTwo) {
		
		this.slainPiecesPlayerOne = slainPiecesPLayerOne;
		this.slainPiecesPlayerTwo = slainPiecesPlayerTwo;
		
		// Calls paintComponent()
		repaint();   
	}

}
