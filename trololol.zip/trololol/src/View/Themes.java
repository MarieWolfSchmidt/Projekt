package View;

import java.awt.Color;

public class Themes {
	private Color p1color = Color.RED;
	private Color p2color = Color.BLACK;
	private Color squareColor = Color.WHITE;
	private Color pSquareColor = Color.GRAY;
	
	public Themes() {
		
	}

	
	public void setTheme(String theme){
		if ( theme.equals("Default theme")){
			this.p1color = Color.RED;
			this.p2color = Color.BLACK;
			this.squareColor = Color.WHITE;
			this.pSquareColor = Color.GRAY;
					
		} else if ( theme.equals("Pink theme")){
			this.p1color = new Color(255, 128, 0);
			this.p2color = Color.GRAY;
			this.pSquareColor = Color.BLACK;
			this.squareColor = new Color(41, 93, 143);
		}
	}
	
	public Color getP1Color(){
		return this.p1color;
	}
	public Color getP2Color(){
		return this.p2color;
	}
	
	public Color getSquareColor(){
		return this.squareColor;
	}
	
	public Color getPSquareColor() {
		return this.pSquareColor;
	}
	
}
