package View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

public class StopWatch {
	private int sec = 0, min = 0, hour = 0, p2sec = 0, p2min = 0, p2hour = 0;
	private String seconds, minutes, hours, txtlbl;
	private ActionListener timePerformer;
	private Timer time;
	
	public StopWatch (int sec, int min , int hour){
		this.sec = sec;
		this.min = min;
		this.hour = hour;
		
	     
	}
	
	
	public String getTime(){
		
		  seconds = Integer.toString(sec);
		  minutes = Integer.toString(min);
		  hours = Integer.toString(hour);
		 
		  if (seconds.length()<2){
			  seconds = "0" + seconds;
		  } 
    	  if (minutes.length()<2){
			  minutes = "0" + minutes;
		  }
    	  if(hours.length() <2){
			  hours = "0" + hours;
		  }
      	
      	  //following if sentences make sure that if the numbers are less than 10 they get a extra 0 in front of them.
      	 
      	  
      	  
		return this.txtlbl = (""+ hours + ":" + minutes + ":" + seconds);
		// the timer needs a actionlistener to be able to count
		
	}
	
	// a function that only stops the timer so it can reset and wont count in the next game
	public void stopTimer(){
		time.stop();
	}
	
	public void resetTimeLabel(){
		
		
		// the timer needs a actionlistener to be able to count
		timePerformer = new ActionListener() {
	          public void actionPerformed(ActionEvent evt) {
	        	  
	        	  
	        	  if (sec < 59){
	        		  sec++; 
	        	  } else if (sec == 59){
	        		  sec = 0;
	        		  min++;
	        		  
	        		  if (min == 60){
	        			  hour++;
	        			  min = 0;
	        		  }
	        	  }
	        	  //following if sentences make sure that if the numbers are less than 10 they get a extra 0 in front of them.
	        	  
	        	  
	          }
	      };
	      //the timer counts in secconds. So the timePerformer actionlistener is activated every 1000 milliseconds or every second.
	      time = new Timer(1000, timePerformer);
	      time.start();
	}

}
