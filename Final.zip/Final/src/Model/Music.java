package Model;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Music {
	
	private Clip soundtrack;
	private boolean isMusicOn = false;

	public void toggleMusic() {
		if (isMusicOn == false ){
			activateMusic();
			this.isMusicOn = true;
		} else {
			stopMusic();
			this.isMusicOn = false;
		}		
	}
	
	public void activateMusic(){
		try {
			InputStream in = new FileInputStream("eye.wav");
			 InputStream bufferedIn = new BufferedInputStream(in);
			 soundtrack = AudioSystem.getClip();
			 AudioInputStream ais = AudioSystem.getAudioInputStream(bufferedIn);
			 
			 soundtrack.open(ais);
			 soundtrack.loop(Clip.LOOP_CONTINUOUSLY);
		 } catch (Exception ex) {
			 System.out.println("Sound file not found");
		 }
	}
	
	public void stopMusic() {
		soundtrack.stop();
		isMusicOn = false;
	}
	
	public void keepMusicPlaying() {
		if (isMusicOn == false) {
			activateMusic();
			isMusicOn = true;
		}
	}
	
	
}
