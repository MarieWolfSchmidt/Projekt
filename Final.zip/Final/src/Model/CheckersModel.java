package Model;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import View.CheckersView;
import View.Themes;

public class CheckersModel {

	private CheckersView view;
	private MovePieces movePieces;
	private List<Pieces> pieceList;
	public RemovePieces removeAllPieces;
	private Music music = new Music();
	public Themes themes = new Themes();
		
	private int squareDim;
	private int pieceSize;
	private int rowsWithPieces;
	private int totalAmountOfPieces;
	private int boardSize = 800;
	protected int finalBoardSize; 

	private boolean isKing = false;
	
	public CheckersModel(CheckersView view) {
		
		// Constructor of the main class of the Model package. 
		this.view = view;
    	this.squareDim = boardSize/view.cmdLineArgument; 
    	this.finalBoardSize = squareDim*view.cmdLineArgument;
    	this.pieceSize = (squareDim/3)*2;
    	this.pieceList = new ArrayList<>();
    	this.movePieces = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize, themes.getP1Color(), themes.getP2Color());
    	this.rowsWithPieces = view.cmdLineArgument / 2 - 1;   
    	this.removeAllPieces = new RemovePieces();
    	
	}
	
	public void game() {
		
		// Is called when the 'New game' is pressed in the GUI - loads the game board with pieces and the score board. 
		
		// Loads the colors from the theme. 
		Color squareColor = themes.getSquareColor();
		Color pieceSquareColor = themes.getPSquareColor();
		Color playerOneColor = themes.getP1Color();
		Color playerTwoColor = themes.getP2Color();
		
		// Move helps moving the pieces - colors from the theme is also send here.  
		this.movePieces = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize, themes.getP1Color(), themes.getP2Color());
		
		// The game menu is called - with color theme as well.
		this.view.menu.game(view.cmdLineArgument, pieceList, boardSize, squareDim, finalBoardSize, pieceSize, squareColor, pieceSquareColor, playerOneColor, playerTwoColor, movePieces);
		
		// Only 3 rows of pieces are added on each side of the board.
		if (rowsWithPieces > 3) {
			rowsWithPieces = 3;
		} else if (rowsWithPieces <= 0) {
			rowsWithPieces = 1;
		}
		// Adds the pieces, one red row and one black row each time.
		for (int i = 0; i < rowsWithPieces; i++) {
			// To make sure the pieces are only placed on the gray squares.
			int nextColumRed, nextColumBlack;
			if (i%2 == 0) {
				nextColumRed = 1;
				nextColumBlack = 0;
			} else {
				nextColumRed = 2;
				nextColumBlack = 1;
			}
			for (int j = 0; j < view.cmdLineArgument; j += 2) {
				view.menu.drawOnBoardPanel.addPieces(playerOneColor, i + 1, j + nextColumRed, squareDim, pieceList, isKing);
				view.menu.drawOnBoardPanel.addPieces(playerTwoColor, view.cmdLineArgument-i, view.cmdLineArgument - j - nextColumBlack, squareDim, pieceList, isKing);
			}
		}
		totalAmountOfPieces = pieceList.size();
		// Handles when the command line argument is an odd number - the right amount of pieces is set.
		if (view.cmdLineArgument % 2 != 0 && view.cmdLineArgument > 6) {
			totalAmountOfPieces = totalAmountOfPieces-2;
		} else {
			totalAmountOfPieces = totalAmountOfPieces;
		}
		movePieces.setAmountOfPieces(totalAmountOfPieces);
		view.menu.drawOnBoardPanel.repaintBoardPanel();
	}
	
	public void menu() {
		this.view.mainMenu.menu();
	}
	
	public void settings() {
		this.view.settingsMenu.settings();
	}
	
	public void highScore() {
		this.view.highScoreMenu.highScore();
	}
	
	public void rules() {
		this.view.rulesMenu.rules();
	}
	
	public void howTo() {
		this.view.howToMenu.howTo();
	}
	
	public void toggleMusic(){
		this.music.toggleMusic();
	}
	
	public void stopMusic(){
		this.music.stopMusic();
	}
	
	public void keepMusicPLaying() {
		this.music.keepMusicPlaying();
	}
	
	public void setTheme(String theme){
		this.themes.setTheme(theme);
	}
	
	public void timerChange(){
		this.view.menu.timeInput();
	}
	
	public void mousePressed(MouseEvent e) {
		movePieces.pressed(e);
	}
	
	public void mouseDragged(MouseEvent e) {
		movePieces.mouseDragged(e, view.menu.drawOnBoardPanel);
	}
	
	public void mouseReleased(MouseEvent e) {
		movePieces.released(e, view.menu.drawOnBoardPanel, view.menu);
		view.menu.drawOnScorePanel.repaintScorePanel(totalAmountOfPieces / 2 - movePieces.getPlayerOnePieceCount(), totalAmountOfPieces / 2 - movePieces.getPlayerTwoPieceCount());
	}
	
	public void turnReset(){
		movePieces.resetTurn();
	}
	
	public void setPieceList(List<Pieces> pieceList) {
		this.pieceList = pieceList;
	}
	
	public List<Pieces> getPieceList() {
		return this.pieceList;
	}
	
}
