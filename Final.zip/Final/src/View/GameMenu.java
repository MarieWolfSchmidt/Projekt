package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import Controller.CheckersController;
import Model.MovePieces;
import Model.Pieces;

public class GameMenu  {
	
	protected CheckersView view;
	public DrawOnBoardPanel drawOnBoardPanel;
	public DrawOnScorePanel drawOnScorePanel;
	
	protected JLabel playerOneTimer;
	protected JLabel playerTwoTimer;
	protected JLabel whosTurn;
	
	private ActionListener timePerformer;
	private Timer timer;
	private MovePieces movePieces;
	
	private int timerSeconds = 0;
	private int timerMinutes = 3;
	private int timerHours = 0;
	
	private StopWatch playerOneStopWatch = new StopWatch(timerSeconds, timerMinutes, timerHours, this);
	private StopWatch playerTwoStopWatch = new StopWatch(timerSeconds, timerMinutes, timerHours, this);
	
	private Color playerOneColor, playerTwoColor;
	
	public GameMenu(CheckersView view){
		this.view = view;
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
	} 

	public void game(int cmdLineArgs, List<Pieces> pieceList, int boardSize, int squareDim, int finalBoardSize, int pieceSize, Color squareCol, Color pSquareCol, Color playerOne, Color playerTwo, MovePieces movePieces){
		// Removes old panel.
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		this.movePieces = movePieces;
		playerOneColor = movePieces.providep1Color();
		playerTwoColor = movePieces.providp2Color();
		
		// The first new panel - the game panel.
		JPanel boardPanel = new JPanel();
		boardPanel.setBounds(6, 6, 800, 800);
		boardPanel.setLayout(null);
		view.getContentPane().add(boardPanel);
		
		// Adding the board and the pieces. 
		this.drawOnBoardPanel = new DrawOnBoardPanel(pieceList, boardSize, squareDim, finalBoardSize, pieceSize, squareCol , pSquareCol, playerOne, playerTwo);
		this.drawOnBoardPanel.repaintBoardPanel();
		this.drawOnBoardPanel.setSize(this.drawOnBoardPanel.finalBoardSize,this.drawOnBoardPanel.finalBoardSize);
		boardPanel.add(this.drawOnBoardPanel);
		
		// The second new panel - the score panel.
		JPanel scorePanel = new JPanel();
		scorePanel.setBounds(916, 6, 334, 800);
		scorePanel.setLayout(null);
		scorePanel.setOpaque(false);
		view.getContentPane().add(scorePanel);
		
		// Labels and buttons of panelTwo.
		JLabel checkersLabel = new JLabel("Checkers", SwingConstants.CENTER);	
		checkersLabel.setBounds(50, 15, 200, 50);	
		checkersLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 28));
		checkersLabel.setForeground(Color.WHITE);
		
		JLabel beginGameLabel = new JLabel("Good luck and have fun!", SwingConstants.CENTER);
		beginGameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		beginGameLabel.setBounds(50, 55, 200, 50);
		beginGameLabel.setForeground(Color.WHITE);
		
		JButton toggleMusicButton = new JButton("Music On/Off");
		toggleMusicButton.setBounds(70, 710, 200, 29);
		toggleMusicButton.setBackground(Color.DARK_GRAY);
		toggleMusicButton.setForeground(Color.WHITE);
		
		JButton backButton = new JButton("Back To Menu");
		backButton.setBounds(70, 760, 200, 29);
		backButton.setBackground(Color.DARK_GRAY);
		backButton.setForeground(Color.WHITE);
		
		// Turn marker.
		whosTurn = new JLabel("TURN", SwingConstants.CENTER);
		whosTurn.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		whosTurn.setBounds(100, 350, 150, 30);
		whosTurn.setOpaque(true);
		whosTurn.setBackground(playerOneColor);
		whosTurn.setForeground(Color.CYAN);
		whosTurn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		
		String seconds = Integer.toString(timerSeconds);
		String minutes = Integer.toString(timerMinutes);
		String hours = Integer.toString(timerHours);
		 
		  if (seconds.length()<2){
			  seconds = "0" + seconds;
		  } 
		  if (minutes.length()<2){
			  minutes = "0" + minutes;
		  }
		  if(hours.length() <2){
			  hours = "0" + hours;
		  }
		
		// Adding timers for both players
		this.playerOneTimer = new JLabel(hours + ":" + minutes + ":" + seconds);
		this.playerOneTimer.setBounds(140, 250, 150, 30);
		this.playerOneTimer.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		this.playerOneTimer.setForeground(Color.WHITE);
		
		this.playerTwoTimer = new JLabel(hours + ":" + minutes + ":" + seconds);
		this.playerTwoTimer.setBounds(140, 450, 150, 30);
		this.playerTwoTimer.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		this.playerTwoTimer.setForeground(Color.WHITE);
		
		// If a timer is already running this has to run so the new timer wont go twice as fast as the old one
		if (timer != null){
			stopTimer();
		}
		
		resetTimeLabel(timerSeconds, timerMinutes, timerHours);
		startTimeLabel();
		
		// Adding the label and buttons to the panel.
		scorePanel.add(toggleMusicButton);
		scorePanel.add(backButton);
		scorePanel.add(checkersLabel);	
		scorePanel.add(beginGameLabel);
		scorePanel.add(whosTurn);
		scorePanel.add(playerOneTimer);
		scorePanel.add(playerTwoTimer);
		
		// Adding actionslisteners.
		CheckersController checkList = new CheckersController(view.checker);
		backButton.addActionListener(checkList);
		boardPanel.addMouseListener(checkList);
		boardPanel.addMouseMotionListener(checkList);
		toggleMusicButton.addActionListener(checkList);
		
		// The third panel - slain pieces
		JPanel slainPiecePanel = new JPanel();
		slainPiecePanel.setBounds(810, 6, 102, 800);
		slainPiecePanel.setLayout(null);
		slainPiecePanel.setOpaque(false);
		
		this.drawOnScorePanel = new DrawOnScorePanel(playerOne, playerTwo);
		this.drawOnScorePanel.repaint();
		this.drawOnScorePanel.setSize(102, 800);
		slainPiecePanel.add(drawOnScorePanel);
			
		// Adding the panel to the JFrame.
		view.getContentPane().add(boardPanel);
		view.getContentPane().add(scorePanel);	
		view.getContentPane().add(slainPiecePanel);
	}

	public void gameOver( String message ) {
		
		// Method that pops up when game is over.
		ImageIcon icon = new ImageIcon("Smiley.svg.png");
		
		int input = JOptionPane.showOptionDialog(null, message, "Game over!", JOptionPane.OK_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, null, null);
		if ( input == JOptionPane.OK_OPTION ){
			view.checker.setPieceList(view.checker.removeAllPieces.removeAllPiecesInList(view.checker.getPieceList()));
			view.checker.game();
		} else {
			view.checker.setPieceList(view.checker.removeAllPieces.removeAllPiecesInList(view.checker.getPieceList()));
			view.mainMenu.menu();
		}
	}
	
	public void startTimeLabel(){
		
		// The timer needs a actionlistener to be able to count
		timePerformer = new ActionListener() {
	          public void actionPerformed(ActionEvent evt) {
	        	 if (movePieces.getPlayerTurn()){
	        		 playerOneStopWatch.setTime(movePieces.getPlayerTurn());
	        		 whosTurn.setBackground(playerOneColor);
	        	 } else {
	        		 playerTwoStopWatch.setTime(movePieces.getPlayerTurn());
	        		 whosTurn.setBackground(playerTwoColor);
	        	 }
	          }
	      };
	      // The timer counts in secconds. So the timePerformer actionlistener is activated every 1000 milliseconds or every second.
	      timer = new Timer(1000, timePerformer);
	      timer.start();
	}
	
	public void stopTimer() {
		// A function that only stops the timer so it can reset and wont count in the next game
		timer.stop();
	}
	
	public void resetTimeLabel(int sec, int min, int hour) {
		playerOneStopWatch.reset(sec, min, hour);
		playerTwoStopWatch.reset(sec, min, hour);
	}
	
	public void timeInput() {
		
		JTextField hoursField = new JTextField(5);
	    JTextField minutesField = new JTextField(5);
	    JTextField secondsField = new JTextField(5);
	    
	    hoursField.setText("0");
	    minutesField.setText("3");
	    secondsField.setText("0");
	    
	    JPanel timerInputPanel = new JPanel();
	    timerInputPanel.add(new JLabel("hours:"));
	    timerInputPanel.add(hoursField);
	    timerInputPanel.add(Box.createHorizontalStrut(15)); // A spacer.
	    timerInputPanel.add(new JLabel("minutes:"));
	    timerInputPanel.add(minutesField);
	    timerInputPanel.add(Box.createHorizontalStrut(15));
	    timerInputPanel.add(new JLabel("seconds:"));
	    timerInputPanel.add(secondsField);

	    int result = JOptionPane.showConfirmDialog(null, timerInputPanel, "Feel free to try out new timer settings by changing the values below", JOptionPane.OK_CANCEL_OPTION);
	    if (result == JOptionPane.OK_OPTION && (hoursField.getText().equals("") || minutesField.getText().equals("") || secondsField.getText().equals(""))) {
	    	result = JOptionPane.CANCEL_OPTION;
	    }
	    if (result == JOptionPane.OK_OPTION) {
	    	this.timerHours = Integer.parseInt(hoursField.getText());
	    	this.timerMinutes = Integer.parseInt(minutesField.getText());
	    	this.timerSeconds = Integer.parseInt(secondsField.getText());    
	    }
	}

}