package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import Controller.CheckersController;

public class HowToMenu {

	CheckersView view;
	
	public HowToMenu(CheckersView view) {
		this.view = view;
	}
	
	public void howTo(){
		
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		JPanel howToPanel = new JPanel();
		howToPanel.setBounds(6, 6, 1250, 800);
		howToPanel.setLayout(null);
		howToPanel.setOpaque(false);
		view.getContentPane().add(howToPanel);
		
		JLabel howToPlayLabel = new JLabel("How To Play", SwingConstants.CENTER);
		howToPlayLabel.setBounds(425, 100, 400, 150);
		howToPlayLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		howToPlayLabel.setForeground(Color.WHITE);
		
		JTextArea howToText = new JTextArea();
		howToText.setBounds(400, 250, 525, 280);
		howToText.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		JButton ruleButton = new JButton("Rules");
		ruleButton.setBounds(1035, 550, 209, 100);
		ruleButton.setBackground(Color.DARK_GRAY);
		ruleButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		ruleButton.setForeground(Color.WHITE);
		
		JButton howToBackButton = new JButton("Back To Menu");
		howToBackButton.setBounds(1035, 690, 209, 100);
		howToBackButton.setBackground(Color.DARK_GRAY);
		howToBackButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		howToBackButton.setForeground(Color.WHITE);
		
		howToPanel.add(howToPlayLabel);
		howToPanel.add(howToText);
		howToPanel.add(ruleButton);
		howToPanel.add(howToBackButton);
		
		howToText.setText("\r\n \r\n - To move the pieces click the piece and drag it to \r\n   the desired desination. "
				+ "\r\n - You can only move the piece to a legal Checkers move."
				+ "\r\n - The piece will go back to the old position, \r\n   if it is moved to an illegal destination, "
				+ "\r\n    and the player has to move their piece again. \r\n");
		howToText.setBackground(Color.LIGHT_GRAY);
		
		CheckersController howToList = new CheckersController(view.checker);
		ruleButton.addActionListener(howToList);
		howToBackButton.addActionListener(howToList);
		
		view.getContentPane().add(howToPanel);

	}
	
}
