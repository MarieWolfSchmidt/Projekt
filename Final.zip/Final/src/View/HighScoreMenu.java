package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import Controller.CheckersController;

public class HighScoreMenu {

	CheckersView view;
	
	public HighScoreMenu(CheckersView view) {
		this.view = view;
	}
	
	public void highScore() {
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		JPanel highScorePanel = new JPanel();
		view.getContentPane().add(highScorePanel);
		highScorePanel.setBounds(6, 6, 1250, 800);
		highScorePanel.setBackground(Color.WHITE);
		highScorePanel.setOpaque(false);
		
		JButton toMenu = new JButton("Back To Menu");
		toMenu.setBounds(1035, 690, 209, 100);
		toMenu.setBackground(Color.DARK_GRAY);
		toMenu.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		toMenu.setForeground(Color.WHITE);
		highScorePanel.add(toMenu);
		
		CheckersController hsList = new CheckersController(view.checker);
		toMenu.addActionListener(hsList);
		
		JLabel hsTitle = new JLabel("High scores", SwingConstants.CENTER);
		hsTitle.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		hsTitle.setBounds(425, 100, 400, 150);
		hsTitle.setForeground(Color.WHITE);
		highScorePanel.add(hsTitle);
		
		JLabel playerName = new JLabel("Player Name");
		playerName.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		playerName.setBounds(475, 200, 200, 100);
		playerName.setForeground(Color.RED);
		highScorePanel.add(playerName);
		
		JLabel amountOfMoves = new JLabel("Moves");
		amountOfMoves.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		amountOfMoves.setBounds(725, 200, 200, 100);
		amountOfMoves.setForeground(Color.WHITE);
		highScorePanel.add(amountOfMoves);
		
		JLabel firstPlace = new JLabel("1.");
		firstPlace.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		firstPlace.setBounds(425, 235, 100, 100);
		firstPlace.setForeground(Color.WHITE);
		highScorePanel.add(firstPlace);
		
		JLabel topPlayer = new JLabel("Ulfur");
		topPlayer.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		topPlayer.setBounds(475, 235, 100, 100);
		topPlayer.setForeground(Color.WHITE);
		highScorePanel.add(topPlayer);
		
		JLabel topMoves = new JLabel("1");
		topMoves.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		topMoves.setBounds(725, 235, 100, 100);
		topMoves.setForeground(Color.WHITE);
		highScorePanel.add(topMoves);
		
		JLabel secondPlace = new JLabel("2.");
		secondPlace.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		secondPlace.setBounds(425, 270, 100, 100);
		secondPlace.setForeground(Color.WHITE);
		highScorePanel.add(secondPlace);
		
		JLabel secondPlayer = new JLabel("Ulfur");
		secondPlayer.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		secondPlayer.setBounds(475, 270, 100, 100);
		secondPlayer.setForeground(Color.WHITE);
		highScorePanel.add(secondPlayer);
		
		JLabel secondMoves = new JLabel("3");
		secondMoves.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		secondMoves.setBounds(725, 270, 100, 100);
		secondMoves.setForeground(Color.WHITE);
		highScorePanel.add(secondMoves);
		
		JLabel thirdPlace = new JLabel("3.");
		thirdPlace.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		thirdPlace.setBounds(425, 305, 100, 100);
		thirdPlace.setForeground(Color.WHITE);
		highScorePanel.add(thirdPlace);
		
		JLabel thirdPlayer = new JLabel("Ulfur");
		thirdPlayer.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		thirdPlayer.setBounds(475, 305, 100, 100);
		thirdPlayer.setForeground(Color.WHITE);
		highScorePanel.add(thirdPlayer);
		
		JLabel thirdMoves = new JLabel("6");
		thirdMoves.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		thirdMoves.setBounds(725, 305, 100, 100);
		thirdMoves.setForeground(Color.WHITE);
		highScorePanel.add(thirdMoves);
		
		JLabel fourthPlace = new JLabel("4.");
		fourthPlace.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		fourthPlace.setBounds(425, 340, 100, 100);
		fourthPlace.setForeground(Color.WHITE);
		highScorePanel.add(fourthPlace);
		
		JLabel fourthPlayer = new JLabel("Mads");
		fourthPlayer.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		fourthPlayer.setBounds(475, 340, 100, 100);
		fourthPlayer.setForeground(Color.WHITE);
		highScorePanel.add(fourthPlayer);
		
		JLabel fourthMoves = new JLabel("did not finish");
		fourthMoves.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		fourthMoves.setBounds(725, 340, 100, 100);
		fourthMoves.setForeground(Color.WHITE);
		highScorePanel.add(fourthMoves);
	}
	
}

