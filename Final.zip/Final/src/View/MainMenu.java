package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Controller.CheckersController;

public class MainMenu {

	CheckersView view;
	
	public MainMenu(CheckersView view) {
		this.view = view;
	}
	
	public void menu() {
		
		// Removes old panels.
		this.view.getContentPane().removeAll();
		this.view.getContentPane().repaint();
		
		// The initial menu panel initiated at startup and its label.
		JPanel panel = new JPanel();
		panel.setOpaque(false);
		panel.setBounds(6, 6, 1250, 800);
		panel.setLayout(null);
		this.view.getContentPane().add(panel);
		
		// Labels and buttons of the initial menu panel.
		JLabel checkersLabel = new JLabel("Let's play Checkers");
		checkersLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		checkersLabel.setForeground(Color.WHITE);
		
		JButton newGameButton = new JButton("New Game");
		newGameButton.setBackground(Color.DARK_GRAY);
		newGameButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		newGameButton.setForeground(Color.WHITE);
		
		JButton scoreButton = new JButton("High Score");
		scoreButton.setBackground(Color.DARK_GRAY);
		scoreButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		scoreButton.setForeground(Color.WHITE);
		
		JButton exitButton = new JButton("Exit");
		exitButton.setBackground(Color.DARK_GRAY);
		exitButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		exitButton.setForeground(Color.WHITE);
		
		JButton rulesButton = new JButton("Rules");
		rulesButton.setBackground(Color.DARK_GRAY);
		rulesButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		rulesButton.setForeground(Color.WHITE);
		
		JButton settingsButton = new JButton("Settings");
		settingsButton.setBackground(Color.DARK_GRAY);
		settingsButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		settingsButton.setForeground(Color.WHITE);

		// Placement and bounds.
		checkersLabel.setBounds(425, 100, 809, 150);
		newGameButton.setBounds(405, 270, 458, 100);
		scoreButton.setBounds(405, 410, 209, 100);
		exitButton.setBounds(654, 550, 209, 100);
		rulesButton.setBounds(405, 550, 209, 100);
		settingsButton.setBounds(654, 410, 209, 100);
		
		// Adding the label and buttons to the panel.
		panel.add(checkersLabel);
		panel.add(newGameButton);
		panel.add(scoreButton);
		panel.add(exitButton);
		panel.add(rulesButton);
		panel.add(settingsButton);
		
		// Adding actionslisteners.
		CheckersController checkList = new CheckersController(this.view.checker);
		
		newGameButton.addActionListener(checkList);
		scoreButton.addActionListener(checkList);
		exitButton.addActionListener(checkList);
		rulesButton.addActionListener(checkList);
		settingsButton.addActionListener(checkList);
		
		// Adding the panel to the JFrame.
		this.view.getContentPane().add(panel);
	}
	
}
