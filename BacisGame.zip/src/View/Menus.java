package View;

import java.awt.Color;
import java.awt.Font;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Controller.CheckersController;
import Model.Pieces;

public class Menus  {
	
	private CheckersView view;
	public Draw draw;

	public Menus(CheckersView view){
		this.view=view;
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
	}
	
	public void menu() {
		// Removes old panels.
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
	
		// The initial menu panel initiated at startup and its label.
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(6, 6, 988, 600);
		panel.setLayout(null);
		view.getContentPane().add(panel);
		
		// Labels and buttons of the initial menu panel.
		JLabel lblNewLabel = new JLabel("Let's play Checkers");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		JButton newGame = new JButton("New Game");
		JButton exitButton = new JButton("Exit");
		
		// Placement and bounds.
		lblNewLabel.setBounds(425, 6, 209, 25);
		newGame.setBounds(400, 70, 209, 200);
		exitButton.setBounds(400, 360, 209, 200);
		
		// Adding the label and buttons to the panel.
		panel.add(lblNewLabel);
		panel.add(newGame);
		panel.add(exitButton);
		
		// Adding actionslisteners.
		CheckersController checkList = new CheckersController(view.checker);
		
		newGame.addActionListener(checkList);
		exitButton.addActionListener(checkList);
		
		// Adding the panel to the JFrame.
		view.getContentPane().add(panel);
	}
	
	public void game(int cmdLineArgs, List<Pieces> pieceList, int boardSize, int squareDim, int finalBoardSize, int pieceSize){
		// Removes old panel.
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		// some kinda explicit comment about how it works with the different panels - also how it works with panelOne and Two.
		
		// The first new panel - the game panel.
		JPanel panelOne = new JPanel();
		panelOne.setBounds(6, 6, 600, 600);
		panelOne.setLayout(null);
		view.getContentPane().add(panelOne);
		
		//Adding the board and the pieces. 
		this.draw = new Draw(pieceList, boardSize, squareDim, finalBoardSize, pieceSize);
		draw.repaintBoardAndPieces();
		draw.setSize(draw.finalBoardSize,draw.finalBoardSize);
		panelOne.setBackground(Color.LIGHT_GRAY);
		panelOne.add(draw);
		
		//The second new panel - the score panel.
		JPanel panelTwo = new JPanel();
		panelTwo.setBounds(610, 6, 385, 600);
		panelTwo.setLayout(null);
		view.getContentPane().add(panelTwo);
		
		// Labels and buttons of the panel.
		JButton backButton = new JButton("Back To Menu");
		JLabel lblCheckers = new JLabel("Checkers");	
		JLabel beginsgame = new JLabel("The player with the red pieces starts the game");	
		
		// Placement and bounds.
		backButton.setBounds(90, 550, 200, 29);
		lblCheckers.setBounds(140, 6, 100, 16);	
		lblCheckers.setFont(new Font("Lucida Grande", Font.PLAIN, 20));

		beginsgame.setBounds(20, 40, 300, 16);	
		
		// Adding the label and buttons to the panel.
		panelTwo.add(backButton);
		panelTwo.add(lblCheckers);	
		panelTwo.add(beginsgame);
			
		//Adding actionslisteners.
		CheckersController checkList = new CheckersController(view.checker);
		backButton.addActionListener(checkList);
		panelOne.addMouseListener(checkList);
		panelOne.addMouseMotionListener(checkList);
			
		// Adding the panel to the JFrame.
		view.getContentPane().add(panelOne);
		view.getContentPane().add(panelTwo);			
	}
	
	public void gameOver(String infoMessage, String titleBar){
		
		ImageIcon icon = new ImageIcon("Smiley.svg.png");
		
		int input = JOptionPane.showOptionDialog(null, infoMessage, titleBar, JOptionPane.OK_OPTION, JOptionPane.INFORMATION_MESSAGE, icon, null, null);
		if (input == JOptionPane.OK_OPTION) {
			view.checker.removePieces();
			view.checker.game();
		} else {
			view.checker.removePieces();
			view.menu.menu();
		}
		
	}

}