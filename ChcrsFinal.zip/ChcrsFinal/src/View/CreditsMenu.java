package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import Controller.CheckersController;

public class CreditsMenu {
	
	CheckersView view;
	
	public CreditsMenu (CheckersView view){
		this.view = view;
	}
	
	public void credits(){
		
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		JPanel creditsPanel = new JPanel();
		creditsPanel.setBounds(6, 6, 1250, 800);
		creditsPanel.setLayout(null);
		creditsPanel.setOpaque(false);
		view.getContentPane().add(creditsPanel);
		
		JLabel creditsLabel = new JLabel("Credits", SwingConstants.CENTER);
		creditsLabel.setBounds(425, 100, 400, 150);
		creditsLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		creditsLabel.setForeground(Color.WHITE);
		
		JTextArea txtCredits = new JTextArea();
		txtCredits.setBounds(200, 250, 925, 300);
		txtCredits.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		JButton creditsBackButton = new JButton("Main Menu");
		creditsBackButton.setBounds(1035, 690, 209, 100);
		creditsBackButton.setBackground(Color.DARK_GRAY);
		creditsBackButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		creditsBackButton.setForeground(Color.WHITE);
		
		creditsPanel.add(creditsBackButton);
		creditsPanel.add(txtCredits);
		creditsPanel.add(creditsLabel);
		
		txtCredits.setText(
				"\r\n - Images"
				+ "\r\n   			Smiley\nhttps://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Smiley.svg/220px-Smiley.svg.png"
				
				+ "\r\n 			Background\nhttp://vignette4.wikia.nocookie.net/steamtradingcards/images/7/79/Borealis_Background_Neon.png" 
				+ "\r\n/revision/latest?cb=20140927233901"
				+"\r\n"
				+ "\r\n - Music"
				+ "\r\n   Eye of the tiger 8-bit"
				+ "\r\n	   https://www.youtube.com/watch?v=VM2UJ6E5D-U");
		txtCredits.setBackground(Color.LIGHT_GRAY);
		
		CheckersController creditsList = new CheckersController(view.checker);
		creditsBackButton.addActionListener(creditsList);
		
		view.getContentPane().add(creditsPanel);
		
	}

}
