package View;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Controller.CheckersController;

public class MenuBar {

	private CheckersView view;
	
	public MenuBar(CheckersView view) {
		this.view = view;
	}
	
	public void menuBar(JFrame frame) {
		
		// Creating a menu bar
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu game = new JMenu("Game");
		JMenu settings = new JMenu("Settings");
		
		JMenuItem newGame = new JMenuItem("New Game");
		JMenuItem exitGame = new JMenuItem("Exit");
		JMenuItem musicButton = new JMenuItem("Music On/Off");
		JMenuItem defaultTheme = new JMenuItem("Default theme");
		JMenuItem pinkTheme = new JMenuItem("Halloween theme");

		newGame.setToolTipText("Starts a new game");
		defaultTheme.setToolTipText("Theme does not change until a new game is started");
		pinkTheme.setToolTipText("Theme does not change until a new game is started");
		
		menuBar.add(game);
		menuBar.add(settings);
		game.add(newGame);
		game.add(exitGame);
		settings.add(musicButton);
		settings.add(defaultTheme);
		settings.add(pinkTheme);
		
		CheckersController titleListeners = new CheckersController(view.checker);
		newGame.addActionListener(titleListeners);
		exitGame.addActionListener(titleListeners);
		musicButton.addActionListener(titleListeners);
		defaultTheme.addActionListener(titleListeners);
		pinkTheme.addActionListener(titleListeners);
		
	}
	
}
