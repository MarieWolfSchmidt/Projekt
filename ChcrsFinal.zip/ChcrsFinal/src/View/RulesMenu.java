package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import Controller.CheckersController;

public class RulesMenu {

	CheckersView view;
	
	public RulesMenu(CheckersView view) {
		this.view = view;
	}
	
	public void rules(){
		
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		JPanel rulePanel = new JPanel();
		rulePanel.setBounds(6, 6, 1250, 800);
		rulePanel.setLayout(null);
		rulePanel.setOpaque(false);
		view.getContentPane().add(rulePanel);
		
		JLabel rulesLabel = new JLabel("RULES", SwingConstants.CENTER);
		rulesLabel.setBounds(425, 100, 400, 150);
		rulesLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		rulesLabel.setForeground(Color.WHITE);
		
		JTextArea txtRules = new JTextArea();
		txtRules.setBounds(400, 250, 525, 280);
		txtRules.setFont(new Font("Calibri", Font.PLAIN, 20));
		
		JButton howToButton = new JButton("How To Play");
		howToButton.setBounds(1035, 550, 209, 100);
		howToButton.setBackground(Color.DARK_GRAY);
		howToButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		howToButton.setForeground(Color.WHITE);
		
		JButton rulesBackButton = new JButton("Main Menu");
		rulesBackButton.setBounds(1035, 690, 209, 100);
		rulesBackButton.setBackground(Color.DARK_GRAY);
		rulesBackButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		rulesBackButton.setForeground(Color.WHITE);
		
		rulePanel.add(rulesLabel);
		rulePanel.add(howToButton);
		rulePanel.add(rulesBackButton);
		rulePanel.add(txtRules);
		
		txtRules.setText(" \r\n - Player at top starts the game."
				+ "\r\n - Each player take turns moving their piece.\r\n - When a piece reaches the opponent's piece it can \r\n    jump over it,"
				+ " which removes the opponent's piece. \r\n - The game is over when there's only one piece left."
				+ "\r\n - The player with the last piece wins the game. \r\n - When a piece reaches the opposite site of the board, "
				+ "\r\n   it becomes \"Dam\", and is now able to move backwards.\r\n - The piece becomes \"Dam\" in the next turn. \r\n");
		txtRules.setBackground(Color.LIGHT_GRAY);
		
		CheckersController rulesList = new CheckersController(view.checker);
		rulesBackButton.addActionListener(rulesList);
		howToButton.addActionListener(rulesList);
		
		view.getContentPane().add(rulePanel);
	}
	
	
}
