package View;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import Controller.CheckersController;

public class SettingsMenu {

	CheckersView view;
	
	public SettingsMenu(CheckersView view) {
		this.view = view;
	}
	
	public void settings(){
		view.getContentPane().removeAll();
		view.getContentPane().repaint();
		
		JPanel settingsPanel = new JPanel();
		settingsPanel.setBackground(Color.WHITE);
		settingsPanel.setBounds(6, 6, 1250, 800);
		settingsPanel.setLayout(null);
		settingsPanel.setOpaque(false);
		view.getContentPane().add(settingsPanel);
		
		JLabel settingsLabel = new JLabel("Settings", SwingConstants.CENTER);
		settingsLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 48));
		settingsLabel.setBounds(425, 100, 400, 150);
		settingsLabel.setForeground(Color.WHITE);
		settingsPanel.add(settingsLabel);
		
		JButton changeTime = new JButton("Change timelimit");
		changeTime.setBounds(530, 300, 209, 50);
		changeTime.setBackground(Color.DARK_GRAY);
		changeTime.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		changeTime.setForeground(Color.WHITE);
		settingsPanel.add(changeTime);
		
		JButton normalTheme = new JButton("Default theme");
		normalTheme.setBounds(530, 390, 209, 50);
		normalTheme.setBackground(Color.DARK_GRAY);
		normalTheme.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		normalTheme.setForeground(Color.WHITE);
		settingsPanel.add(normalTheme);
		
		JButton pinkTheme = new JButton("Halloween theme");
		pinkTheme.setBounds(530, 480, 209, 50);
		pinkTheme.setBackground(Color.DARK_GRAY);
		pinkTheme.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		pinkTheme.setForeground(Color.WHITE);
		settingsPanel.add(pinkTheme);
		
		JButton toggleMusic = new JButton("Music On/Off");
		toggleMusic.setBounds(530, 570, 209, 50);
		toggleMusic.setBackground(Color.DARK_GRAY);
		toggleMusic.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		toggleMusic.setForeground(Color.WHITE);
		settingsPanel.add(toggleMusic);
		
		JButton backButton = new JButton("Main Menu");
		backButton.setBounds(530, 660, 209, 30);
		backButton.setBackground(Color.DARK_GRAY);
		backButton.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		backButton.setForeground(Color.WHITE);
		settingsPanel.add(backButton);
		
		//actionlisteners for settingspanel
		CheckersController settingsList = new CheckersController(view.checker);
		toggleMusic.addActionListener(settingsList);
		backButton.addActionListener(settingsList);
		normalTheme.addActionListener(settingsList);
		pinkTheme.addActionListener(settingsList);
		changeTime.addActionListener(settingsList);	
	}
	
}
