package View;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.List;

import javax.swing.JComponent;

import Model.Pieces;

public class DrawOnBoardPanel extends JComponent implements InterfaceDraw {
	
	private int boardSize;
	private int squareDim;
	private int pieceSize;
	protected int finalBoardSize; // If the supplied commandLineArgument is an odd number then we change the boardSize so it matches.
	
	private List<Pieces> pieceList; 
	
	private Color squareCol;
	private Color pSquareCol;
	private Color playerOne;
	private Color playerTwo;
	
	public DrawOnBoardPanel(List<Pieces> pieceList, int boardSize, int squareDim, int finalBoardSize, int pieceSize, Color squareColor, Color pSquareColor, Color playerOne, Color playerTwo) {
    	this.pieceList = pieceList; 
    	this.boardSize = boardSize;
    	this.squareDim = squareDim;
    	this.finalBoardSize = finalBoardSize;
    	this.pieceSize = pieceSize; 
    	this.squareCol = squareColor;
    	this.pSquareCol = pSquareColor;
    	this.playerOne = playerOne;
    	this.playerTwo = playerTwo;
	}
	
	 protected void paintComponent(Graphics g) {
		 // Override jComponent's function paintComponent to draw the board and the pieces.
	     // The method draws the board on a JPanel utilizing the structure of a coordinate system.
	     // It begins in (0,0) and draws two rows at a time to easier manipulate the colors of the board.
	     // The size of the squares are decided using the size of the board divided by the cmdlineargument. 
	        
	     for (int i = 0; i <= boardSize - squareDim; i += 2*squareDim) { 		// 2*squareDim is added to i to fill in the right color.
	        for (int j = 0; j <= boardSize - squareDim; j += 2*squareDim) {
	        	g.setColor(pSquareCol);
	        	g.fillRect(j, i, squareDim, squareDim);						// Gray square - first row.
	        	g.setColor(squareCol);
	        	g.fillRect(j+squareDim, i, squareDim, squareDim); 			// White square - first row.
	        	g.setColor(pSquareCol);
	        	g.fillRect(j+squareDim, i+squareDim, squareDim, squareDim);	// Gray square - second row.
	        	g.setColor(squareCol);
	        	g.fillRect(j, i+squareDim, squareDim, squareDim);			// White square - second row.
	        }
	     }
	            
	     // Draws a black rectangle to get a black square around the board. 
	     g.setColor(Color.BLACK);
	     // If the supplied cmdLineArgument is odd one will have to calculate the finalBoardSize, because of ints 
	     // way of rounding down. Otherwise one would end up with a little bit of extra board.
	     g.drawRect(0, 0, finalBoardSize, finalBoardSize); 
	            
	     // Draws a black rectangle to get a black square around the board. 
	     g.setColor(Color.BLACK);
	     // If the supplied cmdLineArgument is odd one will have to calculate the finalBoardSize, because of ints 
	     // way of rounding down. Otherwise one would end up with a little bit of extra board.
	     g.drawRect(0, 0, finalBoardSize, finalBoardSize); 
		     
	     // Draws lines around all the square on the board. 
	     drawLinesAroundBoardSquares(g, finalBoardSize, squareDim);
	     // Draws the pieces.
	     drawListOfPieces(g, pieceList, pieceSize, playerOne, playerTwo);
	           	
	 }
	 
	 public void addPieces(Color color, int row, int col, int squareDim, List<Pieces> pieceList, boolean isKing) {
			
		// Instantiates a piece and adds it to the pieceList. 
		 Point p = new Point((col-1)*squareDim+squareDim/2,(row-1)*squareDim+squareDim/2); 
		 Pieces piece = new Pieces(color,p, isKing);
		 pieceList.add(piece);     
	 }
	 
	 public void drawLinesAroundBoardSquares (Graphics g, int finalBoardSize, int squareDim) {
		 
	     // Draws a line around all the squares.
	     for (int i = 0; i < finalBoardSize; i += squareDim) {
	    	 g.drawLine(i, 0, i, finalBoardSize);
	     }
	     for (int i = 0; i < finalBoardSize; i += squareDim) {
	         g.drawLine(0, i, finalBoardSize, i);
	     }	
	 }
	 
	 public void drawListOfPieces(Graphics g, List<Pieces> pieceList, int pieceSize, Color playerOne, Color playerTwo) {
		 
		 // Draws all the pieces in the given list.
		 for(Pieces piece: pieceList) {
			 drawPieces(g, piece.getPoint(), pieceSize, piece, playerOne, playerTwo);
		 }
	 }
	 
	 public void drawPieces(Graphics g, Point point, int pieceSize, Pieces piece, Color playerOne, Color playerTwo) {
		
		 // Draws the individual pieces.
		 int x = (point.x - pieceSize / 2);
		 int y = (point.y - pieceSize / 2);
		 if (piece.getColor().equals(playerOne)) {
			 if (piece.getIsKing() == true){
				 g.setColor(playerOne);
				 g.fillOval(x, y, pieceSize, pieceSize);
				 g.setColor(Color.GREEN);
				 g.drawOval(x, y, pieceSize, pieceSize);
			 } else {
				 g.setColor(playerOne);
				 g.fillOval(x, y, pieceSize, pieceSize); 
			 }
		 } else if (piece.getColor().equals(playerTwo)) {
			 if	(piece.getIsKing() == true) {
				 g.setColor(playerTwo);
				 g.fillOval(x, y, pieceSize, pieceSize);
				 g.setColor(Color.GREEN);
				 g.drawOval(x, y, pieceSize, pieceSize);
			 } else {
				 g.setColor(playerTwo);
				 g.fillOval(x, y, pieceSize, pieceSize); 
			 }
		 }
	 }
	 
	 public void repaintBoardPanel() {
		 
		 // Calls paintComponent()
		 repaint();   
	 }
	 
	 
}
