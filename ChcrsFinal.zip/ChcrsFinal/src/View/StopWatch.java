package View;

import java.awt.event.ActionListener;

import javax.swing.Timer;

import View.GameMenu;

public class StopWatch {
	
	public ActionListener timePerformer;
	
	private GameMenu gameMenu;
	private String ranOutOfTime;

	private String seconds, minutes, hours;
	private int secondsInInt = 0, minutesInInt = 0, hoursInInt = 0;
	
	public StopWatch (int seconds, int minutes, int hours, GameMenu gameMenu){
		this.secondsInInt = seconds;
		this.minutesInInt = minutes;
		this.hoursInInt = hours;
		this.gameMenu = gameMenu;     
	}
	
	public void setTime(boolean player) {
		
		  count(player);
		  seconds = Integer.toString(secondsInInt);
		  minutes = Integer.toString(minutesInInt);
		  hours = Integer.toString(hoursInInt);
		 
		  if (seconds.length() < 2) {
			  seconds = "0" + seconds;
		  } 
    	  if (minutes.length() < 2) {
			  minutes = "0" + minutes;
		  }
    	  if (hours.length() < 2) {
			  hours = "0" + hours;
		  }
      	
      	  //following if sentences make sure that if the numbers are less than 10 they get a extra 0 in front of them.
      	  if (player) {
      		  gameMenu.playerOneTimer.setText(""+ hours + ":" + minutes + ":" + seconds);
      	  } else {
      		  gameMenu.playerTwoTimer.setText(""+ hours + ":" + minutes + ":" + seconds);
      	  }
	}
	
	
	public void count(boolean player) {
		
		// A function that only stops the timer so it can reset and wont count in the next game.
		if (secondsInInt > 0) {
			secondsInInt--; 
		} else if (secondsInInt == 0) {
			secondsInInt = 59;
  		  	minutesInInt--;
  		  	if (minutesInInt < 0) {
  			  hoursInInt--;
  			  minutesInInt = 59;
  		  	}
		}
	
		if (secondsInInt == 0 && minutesInInt == 0 && hoursInInt == 0) {
			if (player) {
				this.ranOutOfTime = "Player one ran out of time and player two wins! Play again?";
			} else {
				this.ranOutOfTime = "Player two ran out of time and player one wins! Play again?";
			}
			gameMenu.gameOver(ranOutOfTime); 
		}
	}
	
	public void reset(int sec, int min, int hour) {
		this.secondsInInt = sec;
		this.minutesInInt = min;
		this.hoursInInt = hour;
	}

}