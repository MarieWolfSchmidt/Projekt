package Controller;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import Model.CheckersModel;

public class CheckersController implements ActionListener, MouseListener, MouseMotionListener {

	private CheckersModel checkersModel;
	
	// Instantiates the CheckersModel. The model works as a gateway for userinput. 
	// Any input that matches a given command is executed. 
	// This is done by using ActionsEvents and MouseEvents. 
	// Both buttons and mouse clicks generated these events and this class handles what happens afterwards. 
	
	public CheckersController(CheckersModel checkerModel){
		this.checkersModel = checkerModel;
		
	}
	
	// All the button events activated by the click on any of the corresponding buttons.
	public void actionPerformed(ActionEvent e) {
			 
	String command = e.getActionCommand();
		if (command.equals("New Game")) {
			checkersModel.game();
		} else if (command.equals("Exit")) {
			System.exit(0);
		} else if (command.equals("Back To Menu")) {
			checkersModel.removePieces();
			checkersModel.menu();
		} else {
			System.out.println("ERROR: Unexpected ActionCommand");
		}
			 	 
	}
		 
	// The mouse events in use. 
	@Override
	public void mousePressed(MouseEvent e) {
		checkersModel.mousePressed(e);
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		checkersModel.mouseDragged(e);
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		checkersModel.mouseReleased(e);			
	}

	// The mouse events not in use. 
	public void mouseMoved(MouseEvent e) {}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}		
		
}

