package ccs.SimpleFrame;

public class Driver {
	public static void main(String []args){
		SimpleFrame SF1 = new SimpleFrame();
	
	SF1.showIt("Dam",700,700);
	}
}
