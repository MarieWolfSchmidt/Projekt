import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CheckersView extends JFrame {
	
	private CheckersModel checker;
	protected int cmdLineArgument;
	JPanel[][] tiles; 
	
	public CheckersView(String args){
		
		this.cmdLineArgument = Integer.parseInt(args);
		
		checker = new CheckersModel(this);
	
		this.setBounds(100, 100, 566, 421);
		this.getContentPane().setBackground(Color.GRAY);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);	
		menu();
	}
	
	public void showIt(String title){
		 this.setTitle(title);
		 this.setVisible(true);
	}
	
	public void menu() {
		
		this.getContentPane().setLayout(null);
		this.getContentPane().removeAll();
		this.getContentPane().repaint();
	
		// The initial menu panel initiated at startup and its label.
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(6, 6, 554, 387);
		panel.setLayout(null);
		this.getContentPane().add(panel);
		
		// Labels and buttons of the initial menu panel.
		JLabel lblNewLabel = new JLabel("Nu skal vi spille Dam!");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		JButton newGame = new JButton("New Game");
		JButton scoreButton = new JButton("High Score");
		JButton exitButton = new JButton("Exit");
		
		// Placement and bounds.
		lblNewLabel.setBounds(168, 6, 209, 25);
		newGame.setBounds(197, 69, 155, 48);
		scoreButton.setBounds(197, 168, 155, 48);
		exitButton.setBounds(197, 271, 155, 48);
		
		// Adding the label and buttons to the panel.
		panel.add(lblNewLabel);
		panel.add(newGame);
		panel.add(scoreButton);
		panel.add(exitButton);
		
		// Adding actionslisteners.
		CheckersController checkList = new CheckersController(checker);
		
		newGame.addActionListener(checkList);
		scoreButton.addActionListener(checkList);
		exitButton.addActionListener(checkList);
		
		// Adding the panel to the JFrame.
		this.getContentPane().add(panel);
	}
	
	public void game(int boardSize) {
		
		// Removing the old panels.
		this.getContentPane().setLayout(null);
		this.getContentPane().removeAll();
		this.getContentPane().repaint();
		
		// Setting color variables. 
		Color BLACK = Color.BLACK;
		Color WHITE = Color.WHITE;
		
		// Setting the JFrame.
		this.setSize(500, 425);
		this.setTitle("Checkers");
	
		// Instantiating the two main panels. 
		JPanel boardPanel = new JPanel(new GridLayout(boardSize, boardSize));
		JPanel scorePanel = new JPanel();
		
		// Adding the two main panels to the Frame. 
		this.getContentPane().add(boardPanel);
		this.getContentPane().add(scorePanel);
		
		// Placing the two main panels. 
		boardPanel.setBounds(0, 0, 400, 400);		
		scorePanel.setBounds(400, 0, 100, 500);
		
		// Adding the black and white tiles to the boardPanel.
		tiles = new JPanel[boardSize][boardSize];
		Color temp;
		for (int i = 0; i < boardSize; i++){
			if ( i%2 == 0){
				temp = BLACK;
			} else {
				temp = WHITE;
			}
			for(int j = 0; j < boardSize; j++){
				
				JPanel panel = new JPanel();
				panel.setBackground(temp);
				tiles[i][j] = panel;
				
				if(temp.equals(BLACK)){
					temp = WHITE;
				} else {
					temp = BLACK;
				}
				boardPanel.add(panel);
			}
		}
		
		// The second new panel - the score panel.		
		// Labels and buttons for the panel.
		JButton backButton = new JButton("Back To Menu");
		
		// Placement and bounds.
		backButton.setBounds(410, 50, 25, 25);
		
		// Adding the label and buttons to the panel.
		scorePanel.add(backButton);
			
		// Adding actionslisteners.
		CheckersController checkList = new CheckersController(checker);
		backButton.addActionListener(checkList);	
		
		
		// Make an mouse event actionlistener that is added to the Jpanel boardpanel 
		
		boardPanel.addMouseListener(checkList);
		
		
		this.setVisible(true);	
	}
	

	// for at registrere, hvor der bliver trykket, kan man tage de individuelle x og y værdier. derefter kan man 
	// tjekke dem op imod, fx hvis pladen er 80 pixels og har n = 8, så kan man lave et forloop, der tillader at 
	// tjekke hvor man er henne.. dette kan gøres ved at loope over hvert felts værdi, dvs. bare ligge et felts værdi til ad gangen
	// og herefter tjekke, hvornår værdien bliver større end den værdi som klikket har fx på x eller y siden.
	// så 1 felt har værdien 10 i dette eksempel, så hvis trykket sker på 50, så skal der loopes 5 gange, før at værdien er "fundet"
	// men så er counteren, dvs. antallet af loop, også et udtryk for feltets enten row eller column. 
	
	public void play(int[][] pieceArray, int cmdLineArgument) {
		
		for (int i = 0; i < cmdLineArgument; i++) {
			for (int j = 0; j < cmdLineArgument; j++) {
				if (pieceArray[i][j] == 1) {
					ImagePanel testPanel = new ImagePanel(new ImageIcon("darth.png").getImage());
					tiles[i][j].add(testPanel);
					tiles[i][j].setVisible(true);	
				} else if (pieceArray[i][j] == -1) {
					ImagePanel testPanel = new ImagePanel(new ImageIcon("luke.png").getImage());
					tiles[i][j].add(testPanel);
					tiles[i][j].setVisible(true);	
				} else {
					continue;
				}
			}
		}	
		
	}		
				
//				tiles[i][j].setBackground(Color.red);
				
//				JLabel testLabel = new JLabel();
//				testLabel.setLayout(null);
//				testLabel.setBackground(Color.GREEN);
////				testLabel.setBounds(0, 0, 50, 50);
////				tiles[i][j].removeAll();
////				tiles[i][j].repaint();
//				tiles[i][j].add(testLabel);
//				tiles[i][j].setVisible(true);

		
}
	
//	public void game(){
//		
//		// Removes old panel.
//		this.getContentPane().removeAll();
//		this.getContentPane().repaint();
//		
//		// some kinda explicit comment about how it works with the different panels - also how it works with panelOne and Two.
//		
//		// The first new panel - the game panel.
//		JPanel panelOne = new JPanel();
//		panelOne.setBackground(Color.WHITE);
//		panelOne.setBounds(6, 6, 372, 387);
//		panelOne.setLayout(null);
//		this.getContentPane().add(panelOne);
//		
//		// Label, bounds and position of text to the first panel.
//		JLabel lblNewLabel = new JLabel("Spilleplade");
//		lblNewLabel.setBounds(17, 39, 278, 125);
//		panelOne.add(lblNewLabel);
//		
//		// The second new panel - the score panel.
//		JPanel panelTwo = new JPanel();
//		panelTwo.setBounds(379, 6, 181, 387);
//		panelTwo.setLayout(null);
//		this.getContentPane().add(panelTwo);
//		
//		// Labels and buttons of the panel.
//		JButton backButton = new JButton("Back To Menu");
//		JLabel lblDam = new JLabel("DAM");	
//		
//		// Placement and bounds.
//		backButton.setBounds(33, 352, 117, 29);
//		lblDam.setBounds(80, 6, 30, 16);	
//		
//		// Adding the label and buttons to the panel.
//		panelTwo.add(backButton);
//		panelTwo.add(lblDam);	
//			
//		// Adding actionslisteners.
//		CheckersController checkList = new CheckersController(checker);
//		backButton.addActionListener(checkList);	
//			
//		// Adding the panel to the JFrame.
//		this.getContentPane().add(panelOne);
//		this.getContentPane().add(panelTwo);			
//	