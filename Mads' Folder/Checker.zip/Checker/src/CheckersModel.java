import java.awt.event.MouseEvent;

public class CheckersModel {

	private CheckersView view;
	private int cmdLineArgument;
	private int pieceArray[][];
	int[] rowAndColumn = new int[2];
	
	public CheckersModel(CheckersView view){
		this.view = view;
		this.cmdLineArgument = view.cmdLineArgument;
	}
	
	public void menu() {
		this.view.menu();
	}
	
	public void game() {
		pieceArray = fillArray(cmdLineArgument);
		this.view.game(cmdLineArgument);
		this.play(pieceArray, cmdLineArgument);
	}
	
	public void play(int[][] pieceArray, int boardSize) {
		this.view.play(pieceArray, cmdLineArgument);
	}
	
	public int[][] fillArray(int n) {
		
		// Very simple version that puts down one piece on each site. 
		// There is either a 0 for no piece.
		// Or a 1 or -1 for a piece. 
		
		// Consider making a version with a class called pieces - because pieces can hold information about where they were before.
		// What side they are on and what not. 
		
		int[][] pieceArray = new int[n][n];
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i == 0 && j == 0) {
					pieceArray[i][j] = 1;
				} else if (i == n-1 && j == n-1) {
					pieceArray[i][j] = -1;
				} else {
					pieceArray[i][j] = 0;
				}
			}
		}
		return pieceArray;
	}
	
	public int[] rowAndColumnClicked(MouseEvent e) {
		
		int xCount = 0;
		int sizeOfPanel = 400/cmdLineArgument;
		int xValueClicked = sizeOfPanel;
		for (int i = 0; i < cmdLineArgument; i++) {			
			if (e.getX() <= xValueClicked) {
				rowAndColumn[0] = xCount;
				break;
			} else {
				xValueClicked += sizeOfPanel;
			}
			xCount += 1;
		}
		
		int yCount = 0;
		int yValueClicked = sizeOfPanel;
		for (int j = 0; j < cmdLineArgument; j++) {
			if (e.getY() <= yValueClicked) {
				rowAndColumn[1] = yCount;
				break;
			} else {
				yValueClicked += sizeOfPanel;
			}
			yCount += 1;
		}
		
		liftPiece(pieceArray, rowAndColumn);
		return rowAndColumn;

	}
	
	public void liftPiece(int[][] pieceArray, int[] rowAndColumn) {
		
		int whatPiece = pieceArray[rowAndColumn[0]][rowAndColumn[1]];
		
		pieceArray[rowAndColumn[0]][rowAndColumn[1]] = 0;
		
		this.play(pieceArray, cmdLineArgument);
	}
	
	
}
