package View;

import java.awt.event.ActionListener;

import javax.swing.Timer;

import View.Menus;

public class StopWatch {
	private int sec = 0, min = 0, hour = 0;
	private String seconds, minutes, hours;
	public ActionListener timePerformer;
	private Timer time;
	private Menus menu;
	private String ranOutOfTime;
	
	public StopWatch (int sec, int min , int hour, Menus menu){
		this.sec = sec;
		this.min = min;
		this.hour = hour;
		this.menu = menu;
	     
	}
	
	
	public void setTime(boolean player){
		
		  count(player);
		  seconds = Integer.toString(sec);
		  minutes = Integer.toString(min);
		  hours = Integer.toString(hour);
		 
		  if (seconds.length()<2){
			  seconds = "0" + seconds;
		  } 
    	  if (minutes.length()<2){
			  minutes = "0" + minutes;
		  }
    	  if(hours.length() <2){
			  hours = "0" + hours;
		  }
      	
      	  //following if sentences make sure that if the numbers are less than 10 they get a extra 0 in front of them.
      	 
      	  
      	  if (player){
      		  menu.playerOneTimer.setText(""+ hours + ":" + minutes + ":" + seconds);
      	  } else {
      		  menu.playerTwoTimer.setText(""+ hours + ":" + minutes + ":" + seconds);
      	  }
		// the timer needs a actionlistener to be able to count
		
	}
	
	// a function that only stops the timer so it can reset and wont count in the next game
	
	
	public void count(boolean player){

  	  if (sec > 0){
  		  sec--; 
  	  } else if (sec == 0){
  		  sec = 59;
  		  min--;
  		  
  		  if (min < 0){
  			  hour--;
  			  min = 59;
  		  }
  	  }
  	  if (sec == 0 && min == 0 && hour == 0){
  		  
  		  if (player) {
  			 this.ranOutOfTime = "Player one ran out of time and player two wins! Play again?";
  		  } else {
  			  this.ranOutOfTime = "Player two ran out of time and player one wins! Play again?";
  		  }
  		 menu.gameOver(ranOutOfTime);
  		  
  	  }
	}
	
	public void reset(int sec, int min, int hour){
		this.sec = sec;
		this.min = min;
		this.hour = hour;
	}

}
