package Model;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import View.CheckersView;
import View.Themes;

public class CheckersModel {

	private CheckersView view;
	private List<Pieces> pieceList;
	private MovePieces move;
	
		
	private int boardSize = 800;
	private int squareDim;
	protected int finalBoardSize; // If the supplied commandLineArgument is an odd number then we change the boardSize so it matches.
	private int pieceSize;
	private int rowsWithPieces;
	private int totalAmountOfPieces;
	public RemovePieces removeAllPieces;
	private boolean isKing = false;
	
	Music music = new Music();
	public Themes themes = new Themes();

	private Color squareColor = Color.WHITE;
	private Color pSquareColor = Color.GRAY;
	private Color p1color = Color.RED;
	private Color p2color = Color.BLACK;
	
	public CheckersModel(CheckersView view) {
		this.view = view;
    	this.squareDim = boardSize/view.cmdLineArgument; 
    	this.finalBoardSize = squareDim*view.cmdLineArgument;
    	this.pieceSize = (squareDim/3)*2;
    	this.pieceList = new ArrayList<>();
    	this.move = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize, themes.getP1Color(), themes.getP2Color());
    	this.rowsWithPieces = view.cmdLineArgument / 2 - 1;   
    	this.removeAllPieces = new RemovePieces();
    	
	}
	
	public void game() {
		Color ssquareColor = themes.getSquareColor();
		Color ppSquareColor = themes.getPSquareColor();
		Color pp1color = themes.getP1Color();
		Color pp2color = themes.getP2Color();
		
		this.move = new MovePieces(pieceList, squareDim, pieceSize, finalBoardSize, themes.getP1Color(), themes.getP2Color());
		this.view.menu.game(view.cmdLineArgument, pieceList, boardSize, squareDim, finalBoardSize, pieceSize, ssquareColor, ppSquareColor, pp1color, pp2color, move);
		
		//Makes sure that there are only 3 rows with pieces per team
		if(rowsWithPieces > 3) {
			rowsWithPieces = 3;
		} else if (rowsWithPieces <= 0){
			rowsWithPieces = 1;
		}
		//Adds the pieces, one red row and one black row each time.
		for (int i = 0; i < rowsWithPieces; i++){
			//To make sure the pieces are only placed on the gray squares.
			int nextColumRed, nextColumBlack;
			if (i%2 == 0){
				nextColumRed = 1;
				nextColumBlack = 0;
			} else {
				nextColumRed = 2;
				nextColumBlack = 1;
			}
			for (int j = 0; j < view.cmdLineArgument; j += 2){
				view.menu.drawOnBoardPanel.addPieces(pp1color, i + 1, j + nextColumRed, squareDim, pieceList, isKing);
				view.menu.drawOnBoardPanel.addPieces(pp2color, view.cmdLineArgument-i, view.cmdLineArgument - j - nextColumBlack, squareDim, pieceList, isKing);
			}
		}
		totalAmountOfPieces = pieceList.size();
		//Makes sure that is the cmdLine Argument is an add number, that the amount of pieces is right.
		if(view.cmdLineArgument%2 !=0 && view.cmdLineArgument>6){
			totalAmountOfPieces=totalAmountOfPieces-2;
		} else{
			totalAmountOfPieces=totalAmountOfPieces;
		}
		move.setAmountOfPieces(totalAmountOfPieces);
		view.menu.drawOnBoardPanel.repaintBoardPanel();
	}
	
	public void menu() {
		this.view.menu.menu();
	}
	
	public void settings() {
		this.view.menu.settings();
	}
	
	public void highScore() {
		this.view.menu.highScore();
	}
	
	public void rules() {
		this.view.menu.rules();
	}
	
	public void howTo() {
		this.view.menu.howTo();
	}
	
	public void toggleMusic(){
		this.music.toggleMusic();
	}
	
	public void setTheme(String theme){
		this.themes.setTheme(theme);
	}
	
	public void timerChange(){
		this.view.menu.timeInput();
	}
	
	public void mousePressed(MouseEvent e) {
		move.pressed(e);
	}
	
	public void mouseDragged(MouseEvent e) {
		move.mouseDragged(e, view.menu.drawOnBoardPanel);
	}
	
	public void mouseReleased(MouseEvent e) {
		move.released(e, view.menu.drawOnBoardPanel, view.menu);
		view.menu.drawOnScorePanel.repaintScorePanel(totalAmountOfPieces / 2 - move.getPlayerOnePieceCount(), totalAmountOfPieces / 2 - move.getPlayerTwoPieceCount());
	}
	
	public void turnReset(){
		move.resetTurn();
	}
	
	public void setPieceList(List<Pieces> pieceList) {
		this.pieceList = pieceList;
	}
	
	public List<Pieces> getPieceList() {
		return this.pieceList;
	}
	
}
