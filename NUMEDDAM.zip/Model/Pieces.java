package Model;
import java.awt.Color;
import java.awt.Point;



public class Pieces  {

	private Color color;
	private Point point;
	protected boolean isKing;
	
	public Pieces(Color color, Point point, boolean isKing) {
		this.color = color;
		this.point = point;
		this.isKing = isKing;
		
	}

	public static boolean contains(int x, int y, Point point, int squareSize) {
	      return (point.x - x) * (point.x - x) + (point.y - y) * (point.y - y) < squareSize / 2 * 
	    		  squareSize / 2;
	   }
	
	public Color getColor() {
		return this.color;
	}
	
	public void setPoint(Point point) {
		this.point = point;
	}
	
	public Point getPoint() {
		return this.point;
	}
	
	public boolean getIsKing(){
	return this.isKing;
}

}
